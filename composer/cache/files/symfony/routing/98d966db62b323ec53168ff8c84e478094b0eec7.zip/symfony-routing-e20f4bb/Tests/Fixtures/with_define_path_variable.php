<?php

$path = '/1/2/3';

return new \Symfony\Component\Routing\RouteCollection();
